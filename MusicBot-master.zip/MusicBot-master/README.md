V1.1.6a

***New***

**!gif [search_term]**

Like rule34, this post a gif. Also nsfw. I am not able to control any content, prepare for some weird shit :p

**!wiki [search_term]**

Need to know what something is? Maybe there's a language barrier. Botzilla help you out!

**easter_eggs**

Added some easter_eggs, goodluck finding them !

***Changes***

- !gif [search_term] is now available for everyone and !gif is added to the welcome message
- !wiki [search_term] is now available for everyone and !wiki is added to the welcome message
- !patchnotes now shows a image to make it look better.
- Optimized !rule34 against spam, Same technique is used in !gif
- updated requirements.txt with needed modules

***Fix***

- !status
!status raised an error. !status is now working again

***New module***

Added **giphypop** to the exciting module list;

**os**
**sys**
**time**
**shlex**
**shutil**
**inspect**
**aiohttp**
**discord**
**asyncio**
**traceback**
**re**
**random**
**urllib**
**time**
**PIL**
**lyricwikia**
**requests**
**LXML**
**subprocess**
**numpy**
**selenium**
**matplotlib**
**ddg3**

-------------------------------------------------------------------------------------------------------------

Version V1.1.4D

***New***

* - !dab
A dab function!

***New [NSFW]***

* - !rule34 [search term]
Rule#34 : If it exists there is porn of it. If not, start uploading. 
Post image within search term and remove image after 10 minutes


* - !rule34_v1
First version I made. This one downloads the image to your server and reupload it to discord. 
No hyperlink in chat. It does work but it is very slow. Is the bot got spammed it can crash with this command.
use !rule34 instead.



***Changes***

* - BotZilla auto-removes his own messages after an amount of time

* - Edited the welcome message for V1.1.4d

* - Making use of the module selenium now. It isnt used but maybe for in the future.. I am planning for a discord chat game but I am not sure how I'm going to do this. Maybe with selenium server side.

Welcome message if someone joins your server:

{
Welcome to our server [YOUR SERVER], [USERNAME WHO JOINS THE SERVER]! 
 
Commands available to you: 
 
 !play 
 Play your favorite youtube music. Use !play [Link] to add a song to te current queue. 
 !queue 
 This command shows the current queue. 
 !np 
 Want to know what song is playing? Use the now play command! 
 !perms 
 Shows your permissions and some additional information 
 !help 
 Information about the bot. Displays all commands 
 !skip 
 Skip current playing song. Skipratio is 0.5 on 4 votes 
 !search 
 Search your favorite song. Use !search [Title of song]. Follow the instruction to navigate correctly 
 !meow 
 Don't ask.. 
 !dab 
 If you have really the need to dab! 
 !8ball 
 8Ball can help you with hard life decisions. Do I play another round? Ask 8Ball! 
 !rule34 
 Need to have more porn into your live? Use this command! 
 
 Be nice to each other and most importantly have fun!
}

***I enable those commands on my server for everyone to use.***

-------------------------------------------------------------------------------------------------------------
Version V1.1.3b

***New***

* - !status (admins only)
Checks the background processes on the server and return the status of it to discord.

* - !8ball
Ask any question to the magic ball! He knows :)

* - !meow 
Don't ask, it was a request :P

* on_member_join *(only triggers when new member is joining the server)*

Created a welcome message alternated for all servers. This welcome message includes the server, the username of the person whos joining and all the commands available to them.
I noticed that there are some people who dislike the bot peep. This is because it spams the chat at random moments. To doge this problem the welcome message appears in the private messages inbox. This way only the user who joins can see this.


***Changes***

* !help
Gave it a bit more information. Nothing special really

//Behind the scene

* - Terminal now shows song title
* - Terminal now displays 8ball logs

- Beta server
Created a discord channel for test purposes. This way the bot doesnt need all those extra resets while testing. 